import hashlib
import base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto import Random
from Crypto.Cipher import AES

class AESCipher(object):

    def __init__(self, key): 
        self.bs = AES.block_size
        self.key = hashlib.sha256(key.encode()).digest()

    def encrypt(self, raw):
        raw = self._pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return base64.b64encode(iv + cipher.encrypt(raw.encode()))

    def decrypt(self, enc):
        enc = base64.b64decode(enc)
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')

    def _pad(self, s):
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)

    @staticmethod
    def _unpad(s):
        return s[:-ord(s[len(s)-1:])]

def dec_data(cipher, key):
    cipher_rsa = PKCS1_OAEP.new(key)
    plain_text = cipher_rsa.decrypt(cipher)
    return plain_text
    
def load_key(file_to_key):
    private_key_file = open(file_to_key, "rb")
    key = RSA.importKey(private_key_file.read())
    private_key_file.close()
    return key

email = "root.cyberq.2021@gmail.com"
reset_data2 = hashlib.sha256(str(email).encode()).hexdigest()
key = load_key("rsa_key.txt")
f = open("aes_key.txt", "rb")
dec_aes_key = dec_data(f.read(), key)
enc_object = AESCipher(str(dec_aes_key))
enc_data = enc_object.encrypt(reset_data2)
enc_res = enc_data.decode('ascii')

print(enc_res)
